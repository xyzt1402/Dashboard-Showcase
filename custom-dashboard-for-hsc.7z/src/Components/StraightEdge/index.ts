export { default } from "./StraightEdge";
