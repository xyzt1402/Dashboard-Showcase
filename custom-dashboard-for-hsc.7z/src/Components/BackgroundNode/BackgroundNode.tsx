import { Handle, NodeProps, Position } from "@xyflow/react";
import React from "react";

const BackgroundNode: React.FC<NodeProps> = ({}) => {
  return <></>;
};

export default BackgroundNode;
