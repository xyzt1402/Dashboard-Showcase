import React from "react";
import customStyle from "./ChartNode.module.scss";
const ChartNode = () => {
  return <div className={customStyle.container}></div>;
};

export default ChartNode;
