import React from 'react'

const ServiceNode = () => {
  return (
    <div>ServiceNode</div>
  )
}

export default ServiceNode