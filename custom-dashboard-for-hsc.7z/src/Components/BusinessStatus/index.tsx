import React from 'react'
import { BanksCheck, CheckingStatus, CheckingStatusKeys, StatusService, TradingCheck } from '../../Types/Status.type'
import { Connection } from '@xyflow/react'
import BusinessStatusTitle from '../BusinessStatusTitle'
import BusinessStatusService from '../BusinessStatusService'
import './index.css'
type Props = {
    data: StatusService<CheckingStatus>;
    typeData: CheckingStatusKeys;
};

const BusinessStatusView = ({ data, typeData }: Props) => {
    return (
        <div className='business-status-view'>
            {/* <div className="hsc-bussiness-status">
                <BusinessStatusTitle titleName="Trading Check" />
                <BusinessStatusService serviceName="Logins" status />
                <BusinessStatusService serviceName="Order Equity" status={false} />
            </div> */}
            <BusinessStatusTitle titleName={typeData} />
            {Object.entries(data).map(([item, status]) => (
                <BusinessStatusService key={item} serviceName={item} status={status === 'OK'} />
            ))}
            {/* <BusinessStatusService serviceName="Logins" status /> */}

        </div>
    )
}

export default BusinessStatusView